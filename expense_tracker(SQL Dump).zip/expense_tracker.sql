-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 27, 2023 at 02:45 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `expense_tracker`
--

-- --------------------------------------------------------

--
-- Table structure for table `expense_category_tbl`
--

CREATE TABLE `expense_category_tbl` (
  `expense_category_id` int(11) UNSIGNED NOT NULL,
  `expense_category_name` varchar(200) NOT NULL,
  `amount` decimal(10,0) NOT NULL DEFAULT 0,
  `created_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `expense_category_tbl`
--

INSERT INTO `expense_category_tbl` (`expense_category_id`, `expense_category_name`, `amount`, `created_at`) VALUES
(26, 'A expense', '45000', '2023-01-27'),
(27, 'B expense', '45000', '2023-01-27');

-- --------------------------------------------------------

--
-- Table structure for table `expense_tbl`
--

CREATE TABLE `expense_tbl` (
  `expense_id` int(11) UNSIGNED NOT NULL,
  `expense_category_id` int(11) UNSIGNED NOT NULL,
  `expense_description` varchar(200) NOT NULL,
  `expense_date` date NOT NULL,
  `created_at` date NOT NULL,
  `deleted` int(1) UNSIGNED NOT NULL,
  `amount_spent` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `expense_tbl`
--

INSERT INTO `expense_tbl` (`expense_id`, `expense_category_id`, `expense_description`, `expense_date`, `created_at`, `deleted`, `amount_spent`) VALUES
(1, 27, 'dddd', '2023-01-27', '2023-01-27', 0, '34'),
(2, 26, 'ff', '2023-01-27', '2023-01-27', 0, '34'),
(3, 26, 'ff', '2023-01-27', '2023-01-27', 0, '34'),
(4, 27, 'dddd', '2023-01-29', '2023-01-27', 0, '5555'),
(5, 27, 'dddd', '2023-01-28', '2023-01-27', 0, '34'),
(6, 27, 'dddd', '2023-01-27', '2023-01-27', 0, '34');

-- --------------------------------------------------------

--
-- Table structure for table `group_tbl`
--

CREATE TABLE `group_tbl` (
  `group_id` int(11) NOT NULL,
  `groupname` varchar(255) NOT NULL,
  `timecreated` date NOT NULL,
  `timemodified` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `group_tbl`
--

INSERT INTO `group_tbl` (`group_id`, `groupname`, `timecreated`, `timemodified`) VALUES
(1, 'Group1', '2023-01-27', '0000-00-00'),
(2, 'Group2', '2023-01-27', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `users_tbl`
--

CREATE TABLE `users_tbl` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `timecreated` date NOT NULL,
  `timeupdated` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users_tbl`
--

INSERT INTO `users_tbl` (`user_id`, `username`, `timecreated`, `timeupdated`) VALUES
(1, 'Checkuser3', '2023-01-27', '0000-00-00'),
(2, 'Checkuser1', '2023-01-27', '0000-00-00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `expense_category_tbl`
--
ALTER TABLE `expense_category_tbl`
  ADD PRIMARY KEY (`expense_category_id`),
  ADD UNIQUE KEY `expense_category_name` (`expense_category_name`);

--
-- Indexes for table `expense_tbl`
--
ALTER TABLE `expense_tbl`
  ADD PRIMARY KEY (`expense_id`),
  ADD KEY `FK_cat_id` (`expense_category_id`);

--
-- Indexes for table `group_tbl`
--
ALTER TABLE `group_tbl`
  ADD PRIMARY KEY (`group_id`);

--
-- Indexes for table `users_tbl`
--
ALTER TABLE `users_tbl`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `expense_category_tbl`
--
ALTER TABLE `expense_category_tbl`
  MODIFY `expense_category_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `expense_tbl`
--
ALTER TABLE `expense_tbl`
  MODIFY `expense_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `group_tbl`
--
ALTER TABLE `group_tbl`
  MODIFY `group_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users_tbl`
--
ALTER TABLE `users_tbl`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `expense_tbl`
--
ALTER TABLE `expense_tbl`
  ADD CONSTRAINT `FK_cat_id` FOREIGN KEY (`expense_category_id`) REFERENCES `expense_category_tbl` (`expense_category_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
