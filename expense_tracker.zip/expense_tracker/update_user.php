<?php
session_start();
require_once('db_config.php');

	if(isset($_POST['submit']) && !empty($_POST['username'])){ 
     $username = mysqli_real_escape_string($con,$_POST['username']);
     $user_id = mysqli_real_escape_string($con,$_POST['getID']);
      
     $update = mysqli_query($con, "UPDATE users_tbl SET username= '".$username."' 
      WHERE user_id = '".$user_id."' ");
     if($update === TRUE)
    {
      echo '
         <script type="text/javascript">
          alert("Success!");
          window.location.replace("expense_user.php");
         </script>';
    }

else{
		echo '
         <script type="text/javascript">
          alert("Error!");
          window.location.replace("userupdate.php ");
         </script>';
	}

}
mysqli_close($con);
?>
