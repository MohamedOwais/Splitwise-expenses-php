1.Unzip the folder
2.Copy the expense_folder in your wamp www folder or xamp htdoc folder
3.Open the expense_folder
5.Open the db_config.php file and change the connection string
6.Install the data
7.Type localhost/expense_manager
8.You are done

You can contact me at     kingwashlds@gmail.com