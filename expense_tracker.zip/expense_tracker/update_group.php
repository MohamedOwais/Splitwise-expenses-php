<?php
session_start();
require_once('db_config.php');

	if(isset($_POST['submit']) && !empty($_POST['groupname'])){ 
     $groupname = mysqli_real_escape_string($con,$_POST['groupname']);
     $group_id = mysqli_real_escape_string($con,$_POST['getID']);
      
     $update = mysqli_query($con, "UPDATE group_tbl SET groupname= '".$groupname."' 
      WHERE group_id = '".$group_id."' ");
     if($update === TRUE)
    {
      echo '
         <script type="text/javascript">
          alert("Success!");
          window.location.replace("expense_group.php");
         </script>';
    }

else{
		echo '
         <script type="text/javascript">
          alert("Error!");
          window.location.replace("groupupdate.php ");
         </script>';
	}

}
mysqli_close($con);
?>
