 <?php
session_start();
require_once('db_config.php');
    if(ISSET($_REQUEST['group_id'])){
        $group_id = $_REQUEST['group_id']; 
        $_SESSION['group_id']=$group_id;
        $sql = mysqli_query($con, "SELECT * FROM `group_tbl` WHERE `group_id`='".$group_id."' ");
        while($update_data = mysqli_fetch_array($sql))
        {
             
        ?>
         <div class="content">
        <div>
            <form action="a.php" method="POST" enctype="multipart/form-data">
                <div style=" margin-left:100px;">
             <br> 
                  
            <div class="form-group">
            <label> Group Name: </label>
                <input type="text" name="groupname" id="groupname" style="margin-left:-50px" class="form-control"   onBlur="this.value=trim(this.value);"  value="<?php echo $update_data['groupname'];?>" required>
            </div> 
           <br>
        
            <?php  ?>
            </div>
         </div>
        <div class="modal-footer">
            <input type="submit" id="submit" name="submit"  value="Add" class="btn btn-primary" style=""/>
             <input type="reset" id="rest" value="Cancel / Reset" class="btn btn-danger" style=""/> 
        </div>
      </div>
   </form>
     <?php 
     }
    }
?>
